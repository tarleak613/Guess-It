import { StyleSheet, Text, View, LogBox, StatusBar } from 'react-native';
import { useFocusEffect, useRoute } from '@react-navigation/native';
import { useEffect, useState } from 'react';
import { data } from "../data"
import CountdownTimerForStartingGame from '../components/CountdownTimerForStartingGame';
import { formatTime } from "../utils";
import { Accelerometer } from 'expo-sensors';
import * as ScreenOrientation from 'expo-screen-orientation';
import Gif from 'react-native-gif';

Array.prototype.getRamdonElement = function () {
    return this[Math.floor(Math.random() * this.length)];
}

export default function HomeScreen({ navigation }) {
    useFocusEffect(() => {
        ScreenOrientation.lockAsync(ScreenOrientation.OrientationLock.LANDSCAPE_RIGHT);
        StatusBar.setHidden(true);
    })
    LogBox.ignoreLogs(['new NativeEventEmitter()']);
    const route = useRoute();
    const category = route.params?.category;
    const backgroundColor = route.params?.backgroundColor;
    const [words] = useState(() => { return data[category] })
    const [gameStarted, setGameStarted] = useState(false)
    const [totalgameTime] = useState(260)
    const [timeLeft, setTimeLeft] = useState(0)
    const [totalScore, setTotalScore] = useState(0)
    const [answers, setAnswers] = useState([])
    const [currentWord, setCurrentWord] = useState("")
    const [tiltedUp, setTiltedUp] = useState(false)
    const [tiltedDown, setTiltedDown] = useState(false)
    const [showGifs, setShowGifs] = useState(false); // State to control the visibility of GIFs
    //seperately for the gif to remain for 2 seconds
      useEffect(() => {
        let timeoutId;
    
        const tiltTimeout = async () => {
            setShowGifs(true); // Show GIFs when tilted down
            timeoutId = setTimeout(() => {
                setShowGifs(false); // Hide GIFs after 2 seconds
            }, 2000);
            await timeout(2000); // Wait for 2 seconds before clearing the timeout
            setShowGifs(false); // Hide GIFs after 2 seconds even if not tilted
        };
    
        if (tiltedDown) {
            tiltTimeout();
        } else {
            setShowGifs(false); // Hide GIFs when not tilted down
            clearTimeout(timeoutId); // Clear the timeout when not tilted down
        }
    
        return () => {
            clearTimeout(timeoutId);
        };
    }, [tiltedDown]);
    
    
    const timeout = (time) => new Promise(resolve => setTimeout(resolve, time));
    let intervalId, gameStartedLocal = false, currentWordLocal = "",isTiltedLocal=false;
    async function startGame() {
        currentWordLocal = words.getRamdonElement()
        setCurrentWord(currentWordLocal)
        setGameStarted(true)
        gameStartedLocal = true
        setTimeLeft(totalgameTime)
        intervalId = setInterval(() => {
            setTimeLeft(t => t - 1);
        }, 1000)
    }
    useEffect(() => {
        if (gameStarted && timeLeft == 0) {
            clearInterval(intervalId);
            navigation.navigate("Category", { category, answers, totalScore, backgroundColor })
        }
    }, [timeLeft])
    useEffect(() => {
        let subscription;
        Accelerometer.setUpdateInterval(1000);
        subscription = Accelerometer.addListener(async (accelerometerData) => {
            if (!gameStartedLocal && !isTiltedLocal) return;
            const threshold = 0.5;
            const isTiltedTowardsFloor = accelerometerData.z < -threshold;
            const isTiltedTowardsSky = accelerometerData.z > threshold;
            if (isTiltedTowardsFloor)
                setTotalScore(s => s + 1)
            if (isTiltedTowardsSky) {
                isTiltedLocal=true
                setTiltedUp(true)
                await timeout(1000)
                isTiltedLocal=false
                setTiltedUp(false)
            }
            if (isTiltedTowardsFloor) {
                isTiltedLocal=true
                setTiltedDown(true)
                await timeout(1000)
                isTiltedLocal=false
                setTiltedDown(false)
            }
            if (isTiltedTowardsFloor || isTiltedTowardsSky) {
                setAnswers(ans => {
                    ans.push({ word: currentWordLocal, answered: isTiltedTowardsFloor })
                    return ([...ans])
                })
                currentWordLocal = words.getRamdonElement()
                setCurrentWord(currentWordLocal)
            }
        });
        return () => {
            if (subscription)
                subscription.remove();
        };
    }, []);
    return (
                    
        <View style={{ ...styles.container, backgroundColor: backgroundColor }}>
        {showGifs && (
            <View style={styles.gifContainerLeft}>
                <Gif
                    source={require('../assets/partypopper.gif')}
                    style={styles.gif}
                />
            </View>
        )}
        {showGifs && (
            <View style={styles.gifContainerRight}>
                <Gif
                    source={require('../assets/partypopper.gif')}
                    style={styles.gif}
                />
            </View>
        )}
            {!gameStarted ?
                <CountdownTimerForStartingGame startGame={startGame} backgroundColor={backgroundColor} />
                :
                <>   
                    <Text style={{ ...styles.text, color: tiltedUp ? "#FF0000" : tiltedDown ? "#00FF00" : "black" }}>{currentWord || ""}</Text>
                    <Text style={styles.text}>{formatTime(timeLeft)}</Text>
                </>
            }
        </View>
    )
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
    },
    text: {
        fontSize: 50,
        textAlign: 'center'
    },
    gifContainerLeft: {
        position: 'absolute',
        top: 0,
        left: 20,
    },
    gifContainerRight: {
        position: 'absolute',
        right: 0, // Adjusted to place it at the right edge of the screen
        bottom: 20, // Adjusted to place it at the bottom of the screen
    },
    gif: {
        width: 100,
        height: 100,
    },
})
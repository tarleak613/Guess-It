import { StyleSheet, Text, View, Pressable, ScrollView, LogBox,ImageBackground, Image } from 'react-native';
import * as ScreenOrientation from 'expo-screen-orientation';
import { useState } from 'react';
import { useFocusEffect } from '@react-navigation/native';
import { categories } from "../categories"
import { categories_bg_image } from '../categories_bg_image';
// import { BlurView } from "@react-native-community/blur";

colors = ['#78D2AF', '#AC9CF3', '#F48CA3', '#CC8BD8', '#F5AF68','#9AD8A2','#E3A6E1','#F5C4A7','#B4B7F0','#FFD75E']
Array.prototype.getRamdonElement = function () {
    return this[Math.floor(Math.random() * this.length)];
}

export default function HomeScreen({ navigation }) {
    LogBox.ignoreLogs(['new NativeEventEmitter()']);
    useFocusEffect(() => {
        ScreenOrientation.lockAsync(ScreenOrientation.OrientationLock.PORTRAIT);
    })
    const [allCategories] = useState(categories, categories_bg_image)
    // const [categoriesBgImage] = useState(categories_bg_image, categories_bg_image)
    return (
        <View style={styles.container}>
            <ImageBackground source={require('../assets/homeScreenBackgroundImage.jpg')} style={styles.header}>
                <Text style={styles.headerText}>GUESS IT</Text>
                <Image source={require('../assets/guessItIcon.png')} style={styles.headerImage}></Image>
            </ImageBackground>
            <ScrollView style={styles.categories}
                contentContainerStyle={styles.categoriesContent}
                indicatorStyle="white"
            >
                {allCategories.map((cat) => {
                    let clr = colors.getRamdonElement();
                    // let clr = 'grey';
                    return (
                            <Pressable
                                style={{ ...styles.categoryContainer, backgroundColor: `${clr}`}}
                                onPress={() => { navigation.navigate("Category", { category: cat, backgroundColor: clr }) }}
                            >
                                {/* <ImageBackground
                                    source={require('../assets/cricket.png')}
                                    style={styles.backgroundImage}
                                    // imageStyle={{ borderRadius: 10 }}
                                > */}
                                    <Text style={styles.categoryText}>{cat.charAt(0).toUpperCase() + cat.slice(1)}</Text>
                                {/* </ImageBackground> */}
                            </Pressable>
                    );
                })}
            </ScrollView>
        </View>
    )
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        // backgroundColor: '#673F69',
        // backgroundColor: '#78D2AF',
        // justifyContent: "space-evenly",
        // borderWidth: 10, // Border width
        borderColor: 'black', // Border color
        borderTopWidth: 1, // Add a black border at the top
        borderTopColor: 'black', // Color of the border
    },
    header: {
        height: 40, // Adjust the height as needed
        fontSize: 40,
        textAlign: "center",
        marginTop: "8%",
        backgroundColor:"black",
        color:"whit",
        borderRadius:25,
        // width:"80%",
        justifyContent:"center",
        alignItems:"center",
        // position:"absolute"
        flexDirection: "row",
    },
    headerText:{
        fontWeight: 'bold',
        // fontStyle: 'italic', 
        // fontFamily:,
        fontSize:30,
        color: 'white',
    },
    headerImage: {
        width: 26,
        height: 26,
        marginHorizontal: 10,
    },
    categories: {
        flex: 1,
        display: "flex",
        marginTop: "5%"
    },
    categoriesContent: {
        display: "flex",
        flexDirection: "row",
        flexWrap: "wrap",
        justifyContent: "space-evenly"
    },
    categoryContainer: {
        display: "flex",
        width: "45%",
        // fontWeight: 'bold',
        // fontStyle: 'italic',
        // backgroundColor: "#FB6D48",
        // backgroundColor: "#FFAF45",
        padding: "10%",
        // paddingVertical:"15%",
        textAlign: "center",
        textAlignVertical: "center",
        justifyContent: "center",
        alignItems: "center",
        marginBottom: "2%",
        borderRadius: 10,
        fontSize: 20
    },
    blurContainer: {
        ...StyleSheet.absoluteFillObject,
        borderRadius: 10,
    },
    // backgroundImage: {
    //     width: '100%',
    //     height: '100%',
    //     justifyContent: 'center',
    //     alignItems: 'center',
    //     overflow: 'hidden',
    // }
});